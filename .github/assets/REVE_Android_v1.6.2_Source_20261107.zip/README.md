# RE:VE Android
Native Java WebView shell with secure HTTPS-only RE:VE origin, persistent website language settings, native product/journal tabs and Android Share sheet. No actual speaker hardware connectivity is claimed.

Build in Android Studio (JDK 17, Gradle 8.11.1, Android SDK 35): `gradle assembleDebug`; resulting APK: `app/build/outputs/apk/debug/app-debug.apk`. For production, configure a dedicated signing key; debug builds are not Play Store submissions. Google Play API-target policy must be rechecked at submission. Do not publish without privacy policy, support contact, store assets and QA.

## v1.6.2 QA corrections
- Native tabs switch labels based on persisted web locale (KO/EN/zh-CN/JA) and retain language when changing tabs.
- Connection and SSL errors use a visible retry panel; HTTPS origin is restricted to RE:VE; external HTTPS, mailto and tel use system apps.
- Top actions: reload and share; progress bar; touch targets at least 48 dp; WebView state restore on rotation.
- Debug signing only; do not distribute as a production Play Store build.
