package site.lexid.reve;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/** RE:VE Android app: origin-restricted WebView, language-aware native navigation. */
public final class MainActivity extends Activity {
    private static final String DOMAIN = "reve.lexid.site";
    private static final String BASE = "https://" + DOMAIN;
    private static final int BACKGROUND = Color.rgb(9, 9, 11);
    private static final int GOLD = Color.rgb(220, 185, 145);
    private static final String[] PATHS = {"/", "/collection/", "/sound-lab/", "/journal/"};
    private static final String[][] TAB_LABELS = {
        {"홈", "제품", "사운드 랩", "저널"},
        {"Home", "Products", "Sound Lab", "Journal"},
        {"首页", "产品", "声音实验室", "专栏"},
        {"ホーム", "製品", "サウンドラボ", "記事"}
    };

    private WebView webView;
    private LinearLayout root;
    private FrameLayout viewport;
    private LinearLayout errorView;
    private ProgressBar progress;
    private final Button[] tabs = new Button[PATHS.length];
    private String language = "ko";
    private boolean mainFrameError = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(0);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        root.setFitsSystemWindows(true);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(15), dp(3), dp(9), dp(3));
        TextView title = new TextView(this);
        title.setText("RE:VE");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setContentDescription("RE:VE");
        header.addView(title, new LinearLayout.LayoutParams(0, dp(45), 1));
        Button reload = toolbarButton("↻", "새로고침 / Refresh");
        reload.setOnClickListener(v -> { if (webView != null) webView.reload(); });
        header.addView(reload);
        Button share = toolbarButton("↗", "공유 / Share");
        share.setOnClickListener(v -> shareCurrentPage());
        header.addView(share);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(51)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(false);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));
        progress.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BACKGROUND));
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));

        viewport = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(BACKGROUND);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return route(request.getUrl());
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                mainFrameError = false;
                errorView.setVisibility(View.GONE);
                progress.setProgress(0);
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                if (!mainFrameError && trusted(Uri.parse(url))) {
                    view.evaluateJavascript("(function(){try{return localStorage.getItem('reve.language')||'ko'}catch(e){return 'ko'}})()", MainActivity.this::setLocaleFromJs);
                }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                mainFrameError = true;
                showError("보안 연결을 확인할 수 없습니다. / Secure connection failed.");
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    mainFrameError = true;
                    showError("인터넷 연결을 확인하고 다시 시도하세요. / Check your connection.");
                }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    mainFrameError = true;
                    showError("페이지를 열 수 없습니다. / Page unavailable (" + response.getStatusCode() + ").");
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 100 && !mainFrameError) progress.setVisibility(View.GONE);
            }
        });
        webView.setDownloadListener((url, userAgent, disposition, mime, size) -> downloadTrusted(url, mime));
        viewport.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        errorView = new LinearLayout(this);
        errorView.setOrientation(LinearLayout.VERTICAL);
        errorView.setGravity(Gravity.CENTER);
        errorView.setPadding(dp(30), dp(24), dp(30), dp(24));
        errorView.setBackgroundColor(BACKGROUND);
        TextView errorMessage = new TextView(this);
        errorMessage.setId(android.R.id.message);
        errorMessage.setTextColor(Color.WHITE);
        errorMessage.setGravity(Gravity.CENTER);
        errorMessage.setTextSize(15);
        errorView.addView(errorMessage, new LinearLayout.LayoutParams(-1, -2));
        Button tryAgain = toolbarButton("↻ 다시 시도 / Retry", "다시 시도 / Retry");
        tryAgain.setTextSize(14);
        tryAgain.setPadding(dp(16), dp(12), dp(16), dp(12));
        tryAgain.setOnClickListener(v -> { errorView.setVisibility(View.GONE); webView.reload(); });
        LinearLayout.LayoutParams tryParams = new LinearLayout.LayoutParams(-2, dp(50));
        tryParams.topMargin = dp(22);
        errorView.addView(tryAgain, tryParams);
        errorView.setVisibility(View.GONE);
        viewport.addView(errorView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(viewport, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setBackgroundColor(Color.rgb(18, 18, 20));
        bottom.setPadding(dp(5), dp(5), dp(5), dp(5));
        for (int index = 0; index < PATHS.length; index++) {
            final int position = index;
            Button tab = toolbarButton(TAB_LABELS[0][index], TAB_LABELS[0][index]);
            tab.setTextSize(12);
            tab.setMinWidth(0);
            tab.setPadding(0, 0, 0, 0);
            tab.setOnClickListener(v -> openNativeTab(position));
            tabs[index] = tab;
            bottom.addView(tab, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(62)));
        setContentView(root);
        updateTabLabels();
        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            Uri launch = getIntent().getData();
            webView.loadUrl(launch != null && trusted(launch) ? launch.toString() : BASE + "/");
        }
    }

    private void showError(String message) {
        runOnUiThread(() -> {
            TextView text = errorView.findViewById(android.R.id.message);
            text.setText(message);
            errorView.setVisibility(View.VISIBLE);
            progress.setVisibility(View.GONE);
        });
    }
    private void setLocaleFromJs(String value) {
        if ("\"en\"".equals(value)) language = "en";
        else if ("\"zh-CN\"".equals(value)) language = "zh-CN";
        else if ("\"ja\"".equals(value)) language = "ja";
        else language = "ko";
        updateTabLabels();
    }
    private void updateTabLabels() {
        int index = language.equals("en") ? 1 : language.equals("zh-CN") ? 2 : language.equals("ja") ? 3 : 0;
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setText(TAB_LABELS[index][i]);
            tabs[i].setContentDescription(TAB_LABELS[index][i]);
        }
    }
    private void openNativeTab(int tab) {
        if (webView == null) return;
        webView.evaluateJavascript("(function(){try{return localStorage.getItem('reve.language')||'ko'}catch(e){return 'ko'}})()", response -> {
            setLocaleFromJs(response);
            String suffix = language.equals("ko") ? "" : "?lang=" + language;
            webView.loadUrl(BASE + PATHS[tab] + suffix);
        });
    }
    private void shareCurrentPage() {
        String current = webView == null ? BASE : webView.getUrl();
        if (current == null || !trusted(Uri.parse(current))) current = BASE;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, current);
        startActivity(Intent.createChooser(send, "Share RE:VE"));
    }
    private void downloadTrusted(String url, String mime) {
        Uri uri = Uri.parse(url);
        if (!trusted(uri)) {
            Toast.makeText(this, "외부 다운로드는 브라우저에서 진행하세요.", Toast.LENGTH_SHORT).show();
            openExternal(uri);
            return;
        }
        String name = uri.getLastPathSegment();
        if (name == null || !name.matches("[A-Za-z0-9._-]{1,160}")) name = "REVE-download";
        try {
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(name);
            request.setMimeType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager != null) manager.enqueue(request);
        } catch (Exception ex) {
            Toast.makeText(this, "다운로드를 시작할 수 없습니다.", Toast.LENGTH_LONG).show();
        }
    }
    private boolean trusted(Uri url) {
        return "https".equalsIgnoreCase(url.getScheme()) && DOMAIN.equalsIgnoreCase(url.getHost());
    }
    private boolean route(Uri url) {
        if (trusted(url)) return false;
        String scheme = url.getScheme();
        if ("https".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) openExternal(url);
        else Toast.makeText(this, "지원하지 않는 링크입니다.", Toast.LENGTH_SHORT).show();
        return true;
    }
    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "이 링크를 열 수 있는 앱이 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }
    private Button toolbarButton(String label, String description) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(GOLD);
        b.setTextSize(17);
        b.setAllCaps(false);
        b.setContentDescription(description);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setMinWidth(dp(48));
        b.setMinimumHeight(dp(48));
        b.setGravity(Gravity.CENTER);
        return b;
    }
    private int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri uri = intent.getData();
        if (uri != null && trusted(uri) && webView != null) webView.loadUrl(uri.toString());
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        if (webView != null) webView.saveState(out);
        super.onSaveInstanceState(out);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) {
            viewport.removeView(webView);
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
